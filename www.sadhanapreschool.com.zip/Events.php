
<?php
$title="Events";
require 'Head.php';
?>

    <!-- Banner starts here -->

    <div style="height: 45px;">

    </div>

    <!-- Banner ends here -->


    <!-- Main content starts here -->

    <div class="featured-blocks">
        <div class="row-fluid">
            <div class="featured-heading">
                <h1>Events</h1>
                <!--<h5>Phasellus ultrices nulla quis</h5> -->
            </div>
        </div>
        <div class="row-fluid">


            <div class="span12">
                <div class="block">
                    <div class="block-title">
                        <h1>Openning</h1>
                        <h2>Sub</h2>
                    </div>
                    <div class="block-content">

                    </div>
                </div>
            </div>



            <div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                <h2>Pellen tesque lacinia</h2>

                <p>Phasellus adipiscing porttitor metus, eget commodo mi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ut hendrerit ante. Phasellus viverra ligula tortor, ut sodales elit tempus eu. Vestibulum mattis sed purus at laoreet. Proin mattis, ante vel adipiscing porttitor, orci elit venenatis nibh, at molestie tortor dolor sit amet urna.  .</p>
            </div>




        </div>
    </div>



    <!-- Featured slider ends here -->


    <!-- Featured content starts here -->



    <!-- Featured ends here -->
    <!-- Featured accordion starts here -->


    <!-- Featured accordion ends here -->

    <!-- Main content ends here -->

<?php
    require 'footer.php';
?>
