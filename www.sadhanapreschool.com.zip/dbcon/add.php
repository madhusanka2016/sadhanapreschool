<html>

<body>



<?php
    require 'user.php';
    require 'dbcon.php';


        $sql = "INSERT INTO user (idno, name, email) VALUES ('34','nameasas','dfdf')";
        $res1=mysqli_query($conn,$sql);




?>



</body>
</html>

