<?php
    $servername="localhost";
    $username="sadhanap";
    $password="eu19mNvS40";
    $db="sadhanap_pclife";

?>

