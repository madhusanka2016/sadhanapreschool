</div>
<div class="container bg-blue b-radius-bottom">
    <div class="site-footer">
        <div class="row-fluid">
            <div class="span3">
                <div class="user-info">

                    <h1><a href="#">Footer</a></h1>
                    <p class="last">Description</p>
                    <span>| 3 hrs ago |</span>
                </div>
            </div>
            <div class="span3">
                <div class="user-info">

                    <h1><a href="#">Footer</a></h1>
                    <p class="last">Description</p>
                    <span>| 3 hrs ago |</span>
                </div>
            </div>
            <div class="span3">
                <div class="user-info">

                    <h1><a href="#">Footer</a></h1>
                    <p class="last">Description</p>
                    <span>| 3 hrs ago |</span>
                </div>
            </div>
            <div class="span3">
                <div class="user-info">

                    <h1><a href="#">Contacts</a></h1>
                    <p class="last">Sadhana Pre School</p>
                    <p class="last">Horagasmulla,</p>
                    <p class="last">Divulapitiya</p>
                    <p class="last">077-3509323</p>
                </div>
            </div>
        </div>
    </div>
    <div class="copy-rights">
        Copyright (c) Sadhana Pre School -  Horagasmulla, Divulapitiya. All rights reserved.
    </div>

</div>
<script src="js/jquery-1.9.1.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/masonry.pkgd.min.js"></script>
<script src="js/imagesloaded.js"></script>
<script src="js/classie.js"></script>
<script src="js/AnimOnScroll.js"></script>

<script>
    new AnimOnScroll( document.getElementById( 'grid' ), {
        minDuration : 1,
        maxDuration : 1,
        viewportFactor : 2
    } );
</script>
<script>
    $('#myCarousel').carousel({
        interval: 1800
    });
</script>




</body>
</html>